Image directory
