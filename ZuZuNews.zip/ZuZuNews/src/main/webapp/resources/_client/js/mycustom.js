/**
 * 
 */
function clickPage(page) {

	var list = document.querySelectorAll('#listpg li.pg');

	for (var i = 0; i < list.length; i++) {
		if (list[i].classList.contains('active')) {
			list[i].classList.remove('active');
		}
		
	}
	list[page].classList.add('active');
}
function clickPage2() {
	var list = document.querySelectorAll('#listpg li.pg');
	var acti = 0;
	for (var i = 0; i < list.length; i++) {
		if (list[i].classList.contains('active')) {
			list[i].classList.remove('active');
			if(i<2){
				acti = i+1;
			}else{
				acti = 2;
			}
		}
	}

	list[acti].classList.add('active');
}
