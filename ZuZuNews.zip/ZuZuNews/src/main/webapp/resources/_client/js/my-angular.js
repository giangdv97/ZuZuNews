var app = angular.module('myapp', []);
app.controller('mycontroller', function($scope, $http) {
	$scope.page = 0;
	$scope.populars = [];

	$scope.getArticle = function() {
		$http.get('popular/' + $scope.page).then(function(result) {
			$scope.populars = result.data;
		});
	}
	$scope.changePage = function(page) {
		$scope.page = page;
		console.log(page);
		$scope.getArticle();
	}
	$scope.nextPage = function() {
		console.log($scope.page);
		if ($scope.page < 5) {
			$scope.page = $scope.page + 1;
			$scope.getArticle();
		}
	}
	
	$scope.prevPage = function() {
		console.log($scope.page);
		if ($scope.page > 0) {
			$scope.page = $scope.page - 1;
			$scope.getArticle();
		}
	}
});