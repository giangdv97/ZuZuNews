package com.news.model;

import java.util.Date;

public class ViewModel {

	public long id; 
	public ArticleModel article;
	public AccountModel user;
	public String viewerIp;
	public Date CreatedAt;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public ArticleModel getArticle() {
		return article;
	}
	public void setArticle(ArticleModel article) {
		this.article = article;
	}
	public AccountModel getUser() {
		return user;
	}
	public void setUser(AccountModel user) {
		this.user = user;
	}
	public String getViewerIp() {
		return viewerIp;
	}
	public void setViewerIp(String viewerIp) {
		this.viewerIp = viewerIp;
	}
	public Date getCreatedAt() {
		return CreatedAt;
	}
	public void setCreatedAt(Date createdAt) {
		CreatedAt = createdAt;
	}
	
	
	
}
