package com.news.model;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.news.entity.Account;

public class CommentModel {

	public long id;
	public String content;
	public ArticleModel article;
	public Account user;
	public Date createdAt;
	public Date updatedAt;
	public int active;
	List<CommentModel> commentChild;

	public CommentModel() {
		commentChild = new ArrayList<CommentModel>();
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public ArticleModel getArticle() {
		return article;
	}

	public void setArticle(ArticleModel article) {
		this.article = article;
	}

	public Account getUser() {
		return user;
	}

	public void setUser(Account account) {
		this.user = account;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	public List<CommentModel> getCommentChild() {
		return commentChild;
	}

	public void setCommentChild(List<CommentModel> commentChild) {
		this.commentChild = commentChild;
	}
	
	public String getDateTime() {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy hh:mm");
		return df.format(createdAt);
	}

}
