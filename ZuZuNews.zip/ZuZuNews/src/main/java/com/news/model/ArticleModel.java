package com.news.model;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.news.entity.CategoryArticle;

public class ArticleModel {

	private long id;
	private CategoryArticle category;
	private String title;
	private String description;
	private String content;
	private String thumb;
	private int commentCount;
	private int views;
	private String tag;
	private String slug;
	private int active;
	private Date createdAt;
	private Date updatedAt;
	private String dateTime;
	private List<TagModel> tags;
	private List<CommentModel> comments;

	public ArticleModel() {
		tags = new ArrayList<TagModel>();
		comments = new ArrayList<CommentModel>();
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public CategoryArticle getCategory() {
		return category;
	}

	public void setCategory(CategoryArticle categoryArticle) {
		this.category = categoryArticle;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getThumb() {
		return thumb;
	}

	public void setThumb(String avatar) {
		this.thumb = avatar;
	}

	public List<CommentModel> getComments() {
		return (List<CommentModel>) comments;
	}

	public void setComments(List<CommentModel> comments) {
		this.comments = comments;
	}

	public int getViews() {
		return views;
	}

	public void setViews(int views) {
		this.views = views;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getSlug() {
		return slug;
	}

	public void setSlug(String slug) {
		this.slug = slug;
	}

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getDateTime() {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm");

		this.dateTime = df.format(createdAt);
		return this.dateTime;
	}

	public int getCommentCount() {
		return commentCount;
	}

	public void setCommentCount(int commentCount) {
		this.commentCount = commentCount;
	}

	public List<TagModel> getTags() {
		return tags;
	}

	public void setTags(List<TagModel> tags) {
		this.tags = tags;
	}

}
