package com.news.model;

import java.util.List;

import com.news.entity.Article;

public class CategoryArticleModel {

	public Long id;
	public String title;
	public List<CategoryArticleModel> children;
	public List<Article> articles;
	
	public Long getId() {
		return id;
	}
	public void setId(Long long1) {
		this.id = long1;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<CategoryArticleModel> getChildren() {
		return children;
	}
	public void setChildren(List<CategoryArticleModel> children) {
		this.children = children;
	}
	public List<Article> getArticles() {
		return articles;
	}
	public void setArticles(List<Article> list) {
		this.articles = list;
	}
	
	
}
