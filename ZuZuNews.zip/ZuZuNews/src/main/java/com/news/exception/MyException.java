package com.news.exception;

public class MyException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
	public MyException(String ms) {
		super(ms);
	}

}
