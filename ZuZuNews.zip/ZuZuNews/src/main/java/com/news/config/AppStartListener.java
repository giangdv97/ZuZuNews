package com.news.config;

import java.text.Normalizer;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.news.dao.AccountDao;
import com.news.dao.ArticleDao;
import com.news.entity.Account;
import com.news.entity.Article;



@Component
public class AppStartListener implements ApplicationListener<ContextRefreshedEvent>{

	@Autowired
	AccountDao accountDao;
	@Autowired
	ArticleDao articleDao;
	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		Account admin=accountDao.getUserByEmail("admin@admin.com");
		admin.setPassword(passwordEncoder.encode("admin"));
		accountDao.save(admin);
		
	}
	
	public String covertStringToURL(String str) {
		   try {
		       String temp = Normalizer.normalize(str, Normalizer.Form.NFD);
		       Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
		       return pattern.matcher(temp).replaceAll("").toLowerCase().replaceAll(" ", "-").replaceAll("đ", "d");
		   } catch (Exception e) {
		       e.printStackTrace(); 
		   }
		   return "";
		}

}
