package com.news.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class EnableSecurityFilter extends AbstractSecurityWebApplicationInitializer{

}
