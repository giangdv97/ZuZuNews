package com.news.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.news.controller.AsideRightInterceptor;
import com.news.controller.CookieLoginInterceptor;
import com.news.controller.HomeInterceptor;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = { "com.news" })

public class MvcConfig implements WebMvcConfigurer {


	@Autowired
	CookieLoginInterceptor cookieLoginInterceptor;

	@Autowired
	HomeInterceptor homeInterceptor;

	@Autowired
	AsideRightInterceptor asideInterceptor;

	public void configureViewResolvers(ViewResolverRegistry registry) {
		registry.jsp().prefix("/WEB-INF/views/").suffix(".jsp");
	}

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/public/**").addResourceLocations("/resources/");
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(homeInterceptor).addPathPatterns("/**");
		registry.addInterceptor(asideInterceptor)
				.addPathPatterns("/", "/home", "/category/**", "/article/**", "/user/**", "/tag/**")
				.excludePathPatterns("/public/**");
		registry.addInterceptor(cookieLoginInterceptor).excludePathPatterns("/logout", "/public/**");
	}

}
