package com.news.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.news.dao.ArticleDao;

@Component

public class AsideRightInterceptor extends HandlerInterceptorAdapter {

	@Autowired
	ArticleDao articleDao;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		int limit;

		// Most views
		limit = 6;
		request.setAttribute("mostViews", articleDao.getMostViewArticles(limit));
		// End most views

		// Most views
		limit = 20;
		request.setAttribute("mostComments", articleDao.getMostCommentArticles(limit));
		// End most views
		
		return true;
	}
}
