package com.news.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.news.dao.ArticleDao;
import com.news.dao.SlideDao;
import com.news.entity.Article;
import com.news.entity.CategoryArticle;
import com.news.model.ArticleModel;
import com.news.service.CategoryService;
import com.news.service.PopularService;

@Controller

public class Homecontroller {

	@Autowired
	SlideDao slideDao;
	
	@Autowired
	PopularService popularService;
	
	@Autowired
	CategoryService categoryService;
	
	@Autowired
	ArticleDao articleDao;
	
	@GetMapping(value = {"/", "/home"})
	public String getHome(Model model, HttpServletRequest request) {
		
		@SuppressWarnings("unchecked")
		List<CategoryArticle> cats = (List<CategoryArticle>) request.getAttribute("categories");
		int limit;
		
		//Slide
		model.addAttribute("slides", slideDao.findAll());
		//End slide
		
		// Trending-article
		model.addAttribute("trendings", categoryService.getTrendingArticlesByCategoryId(cats));
		// End trending-article
		
		
		// Newest article of each category
		limit = 5;
		model.addAttribute("newests", categoryService.getNewestArticlesByCategoryIdWithLimit(cats, limit));
		// End newest article of each category
		
		return "home";
	}
	
	@GetMapping("/popular/{page}")
	public ResponseEntity<Object> getPopularArticles(@PathVariable("page") int page){
		List<Article> list=articleDao.getPopularArticle(PageRequest.of(page, 5));
		List<ArticleModel> result=new ArrayList<ArticleModel>();
		list.stream().forEach(a->{
			result.add(popularService.convert(a));
		});
		return new ResponseEntity<Object>(result, HttpStatus.OK);
		
	}
	
}
