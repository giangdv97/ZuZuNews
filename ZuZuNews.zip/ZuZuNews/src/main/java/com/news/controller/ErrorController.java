package com.news.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller

public class ErrorController {

	private String pageName;
	private String title;
	private String message;

	@GetMapping("/error-404")
	public String error404(Model model, HttpServletRequest req) {
		pageName = "error-page";
		title = "ERROR 404";
		String message = req.getParameter("message");
		if (message == null)
			message = "<h1>Page not found<h1>";

		model.addAttribute("pageName", pageName);
		model.addAttribute("title", title);
		model.addAttribute("message", message);

		return "main-frame";
	}

	@GetMapping("/error-403")
	public String error403(Model model) {
		pageName = "error-page";
		title = "ERROR 403";
		message = "You are not an adminstrator";

		model.addAttribute("pageName", pageName);
		model.addAttribute("title", title);
		model.addAttribute("message", message);

		return "main-frame";
	}

	@GetMapping("/error-500")
	public String error500(Model model, HttpServletRequest req) {
		pageName = "error-page";
		title = "ERROR 500";
		String message = req.getParameter("message");

		model.addAttribute("pageName", pageName);
		model.addAttribute("title", title);
		model.addAttribute("message", message);

		return "main-frame";
	}
	
	//bad request
	@GetMapping("/error-400")
	public String error400(Model model, HttpServletRequest req) {
		pageName = "error-page";
		title = "ERROR 400";
		String message = req.getParameter("message");
		if(message == null)
			message = "<h1>The URL is not valid. Please don't change our url!";

		model.addAttribute("pageName", pageName);
		model.addAttribute("title", title);;
		model.addAttribute("message", message);

		return "main-frame";
	}
	
	@GetMapping("/error")
	public String getError(Model model, HttpServletRequest req) {
		pageName = "error-page";
		title = "ERROR";
		String message = req.getParameter("message");
		if(message == null)
			message = "<h1>Has error while do your request. Please try again!";
		
		model.addAttribute("title", title);
		model.addAttribute("pageName", pageName);
		model.addAttribute("message", message);
		return "main-frame";
	}
}
