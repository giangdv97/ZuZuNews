package com.news.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.news.dao.CategoryArticleDao;
import com.news.entity.CategoryArticle;

@Component
@RequestMapping(value = "/**", method = RequestMethod.GET)

public class HomeInterceptor extends HandlerInterceptorAdapter{

	@Autowired
	CategoryArticleDao categoryArticle;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		
		List<CategoryArticle> categories = categoryArticle.findAll();	
		
		request.setAttribute("categories", categories);
		
		return super.preHandle(request, response, handler);
	}

}
