package com.news.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.news.entity.Account;
import com.news.service.CommentService;

@Controller
public class CommentController {

	@Autowired
	CommentService commentService;
	
	@GetMapping("/comment")
	public String getCommentController() {
		return null;
	}

	@PostMapping("/comment")
	public String postCommentController(HttpServletRequest req, Model model, @ModelAttribute Account acc) {
		long articleId = 0;
		long commentParentId = 0;
		String content = null;

		try {
			articleId = Long.parseLong(req.getParameter("articleId"));
			commentParentId = Long.parseLong(req.getParameter("commentParentId"));
			content = req.getParameter("contentComment");
		} catch (Exception e) {
			model.addAttribute("message", "Gap loi khi xu ly yeu cau, vui long thu lai!");
			return "redirect: error500";
		}

		commentService.saveComment(articleId, commentParentId, content, req);
		return "redirect: article/redirect/" + articleId;
	}
}
