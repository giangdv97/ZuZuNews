package com.news.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.news.service.LoginService;

@Controller

public class AdminHomeController {

	@Autowired
	LoginService loginService;

	@GetMapping("/admin")
	public String dashboard(Model model, HttpServletRequest req) {

		return "dashboard";

	}
}
