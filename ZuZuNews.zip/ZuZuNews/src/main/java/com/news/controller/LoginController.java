package com.news.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.news.service.LoginService;

@Controller

public class LoginController {

	private String title;
	private String pageName;

	@Autowired
	LoginService loginService;

	@GetMapping("/login")
	public String getLogin(Model model, HttpServletRequest req) {
		/*
		 * if (loginService.getSessionLogin(req) != null) { return "redirect: home"; }
		 */

		title = "ZuZuNews Login";
		pageName = "login";
		model.addAttribute("title", title);
		model.addAttribute("pageName", pageName);

		return "main-frame";
	}

	
	
	/*
	 * @PostMapping("/login") public String postLogin(Model model,
	 * HttpServletRequest req, HttpServletResponse res) { String email =
	 * req.getParameter("email").trim(); String password =
	 * req.getParameter("password").trim(); String remember =
	 * req.getParameter("remember");
	 * 
	 * if (remember != null) remember = "checked";
	 * 
	 * Map<String, String> infoLogin = new HashMap<String, String>();
	 * infoLogin.put("email", email); infoLogin.put("password", password);
	 * infoLogin.put("remember", remember);
	 * 
	 * if (email.equals("") || password.equals("")) {
	 * loginService.addInfoLoginIntoModel(model, infoLogin);
	 * model.addAttribute("errorLogin", "Email and password are require"); return
	 * getLogin(model, req); }
	 * 
	 * AccountModel accountModel = loginService.getUser(email);
	 * 
	 * if (accountModel == null) { loginService.addInfoLoginIntoModel(model,
	 * infoLogin); model.addAttribute("errorLogin", "The account is never exists!");
	 * return getLogin(model, req); } else if (loginService.checkPassword(infoLogin,
	 * accountModel)) {
	 * 
	 * if (!loginService.checkActive(accountModel)) {
	 * loginService.addInfoLoginIntoModel(model, infoLogin);
	 * model.addAttribute("errorLogin",
	 * "Your account was blocked or not yet verified!"); return getLogin(model,
	 * req); } loginService.generateSessionLogin(accountModel, req); if (remember !=
	 * null) loginService.generateCookieLogin(accountModel, res);
	 * 
	 * if (loginService.isAdmin(accountModel)) return "redirect: admin";
	 * 
	 * return "redirect: user";
	 * 
	 * } else { loginService.addInfoLoginIntoModel(model, infoLogin);
	 * model.addAttribute("errorLogin", "Your password is wrong!"); return
	 * getLogin(model, req); } }
	 */

	/*
	 * @GetMapping("/logout") public String getLogout(HttpServletRequest req,
	 * HttpServletResponse res) { loginService.deleteCookieLogin(res);
	 * loginService.deleteSessionLogin(req);
	 * 
	 * return "redirect: home"; }
	 */

}
