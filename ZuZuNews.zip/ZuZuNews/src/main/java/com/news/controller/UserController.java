package com.news.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.news.model.AccountModel;
import com.news.service.LoginService;

@Controller

public class UserController {

	private String title;
	private String pageName;
	
	@Autowired
	LoginService loginService;
	
	@GetMapping("/user")
	public String getUserInfo(HttpServletRequest req, Model model) {
		AccountModel user = loginService.getSessionLogin(req);
		if(user == null)
			return "redirect: login";
		title = "User info";
		pageName = "user-info";
		
		model.addAttribute("title", title);
		model.addAttribute("pageName", pageName);
		
		return "main-frame";
	}
}
