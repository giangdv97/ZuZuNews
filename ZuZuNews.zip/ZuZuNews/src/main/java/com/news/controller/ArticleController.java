package com.news.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.proxy.Dispatcher;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.DispatcherServlet;

import com.news.dao.ArticleDao;
import com.news.entity.Article;
import com.news.exception.MyException;
import com.news.model.ArticleModel;
import com.news.service.ArticleService;

@Controller

public class ArticleController {

	@Autowired
	ArticleDao articleDao;
	@Autowired
	ArticleService articleService;

	String title;
	String pageName;

	@GetMapping("/article/*/{articleId}")
	public String getArticle(@PathVariable("articleId") long articleId, Model model) {

		
		Article article = articleDao.getArticleWithComments(articleId);

		if (article == null)
			throw new MyException("<h1> Article Id <b>" + articleId + "</b> is not valid! </h1>");

		else {
			if (article.getActive() == 1) {
				title = "Article page";
				pageName = "article-page";
				ArticleModel articleModel = articleService.convertArticleToArticleModel(article);
				model.addAttribute("articleModel", articleModel);
				model.addAttribute("relatedArticles",
						articleService.getRelatedArticles(articleModel.getTags(), articleModel.getId()));

			} else
				throw new MyException("<h1> Article Id <b>\" + articleId + \"</b> is not actived at the moment! </h1>");

		}

		model.addAttribute("title", title);
		model.addAttribute("pageName", pageName);
		return "main-frame";
	}

}
