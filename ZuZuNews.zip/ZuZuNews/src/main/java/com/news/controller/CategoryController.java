package com.news.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.news.dao.ArticleDao;
import com.news.entity.CategoryArticle;
import com.news.exception.MyException;
import com.news.service.CategoryService;

@Controller

public class CategoryController {

	@Autowired
	CategoryService categoryService;

	@Autowired
	ArticleDao articleDao;

	String title;
	String pageName;

	@GetMapping("/category")
	public String getCategories(Model model, HttpServletRequest request) {
		int page = 0;
		int maxResult = 5;
		title = "Category list";
		pageName = "category-list";

		@SuppressWarnings("unchecked")
		List<CategoryArticle> cats = (List<CategoryArticle>) request.getAttribute("categories");
		model.addAttribute("cats", categoryService.getNewestArticlesByCategoryIdWithPageable(cats, page, maxResult));
		model.addAttribute("title", title);
		model.addAttribute("pageName", pageName);

		return "main-frame";
	}

//	 @GetMapping("/category/ */*")
//
//	public String get404Error(Model model) {
//		title = "ERROR";
//		pageName = "404-page";
//		String content = "URL invalid";
//		
//		model.addAttribute("title", title);
//		model.addAttribute("pageName", pageName);
//		model.addAttribute("content", content);
//		return "main-frame";
//	}

	@SuppressWarnings("unchecked")
	@GetMapping("/category/*/{catId}")
	public String getAllArticleByCatId(@PathVariable("catId") long catId, Model model, HttpServletRequest request) {

		String catTitle = categoryService
				.checkCategoryIdValid((List<CategoryArticle>) request.getAttribute("categories"), catId);
		if (!catTitle.equals("")) {
			title = "Category";
			pageName = "category";
			int page = 0;
			int maxResult = 40;

			model.addAttribute("categoryArticle",
					categoryService.getAllArticleByCatId(catTitle, catId, page, maxResult));
			model.addAttribute("title", title);
			model.addAttribute("pageName", pageName);
			return "main-frame";
		} else
			throw new MyException("<h1>Category has id: " + catId + " not found</h1>");

	}

}
