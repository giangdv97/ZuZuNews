package com.news.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.news.service.ArticleService;

@Controller

public class TagController {

	private String title;
	private String pageName;
	
	@Autowired
	ArticleService articleService;
	
	@GetMapping("/tag/{tagTitle}/{tagId}")
	public String getArticlesByTag(@PathVariable("tagTitle") String tagName ,@PathVariable("tagId") Long tagId, Model model) {
		title = "Articles by tag";
		pageName = "article-list";
		String tagTitle = tagName;
		model.addAttribute("title", title);
		model.addAttribute("pageName", pageName);
		model.addAttribute("tagTitle", tagTitle);
		model.addAttribute("articles", articleService.getArticlesByTag(tagId));
		return "main-frame";
	}
}
