package com.news.controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.news.exception.MyException;

@ControllerAdvice
public class ExceptionHandlerController {

	@ExceptionHandler(MyException.class)
	public String xuLy(MyException ex, Model model) {
		String title = "ERROR";
		String pageName = "error-page";
		String message = ex.getMessage();
		model.addAttribute("title", title);
		model.addAttribute("pageName", pageName);
		model.addAttribute("message", message);
		return "main-frame";
	}
}
