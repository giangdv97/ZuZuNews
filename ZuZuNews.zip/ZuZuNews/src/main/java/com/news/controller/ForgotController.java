package com.news.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.news.model.AccountModel;
import com.news.service.ForgotPasswordService;
import com.news.service.LoginService;

@Controller

public class ForgotController {

	private String title;
	private String pageName;

	@Autowired
	LoginService loginService;
	@Autowired
	ForgotPasswordService forgotPasswordService;
	
	@GetMapping("/forgot-password")
	public String getForgotPassword(Model model) {
		title = "Forgot password";
		pageName = "forgot-password";

		model.addAttribute("title", title);
		model.addAttribute("pageName", pageName);

		return "main-frame";
	}

	@PostMapping("/forgot-password")
	public String postForgotPassword(HttpServletRequest req, Model model) {
		String email = req.getParameter("email").trim();
		if (email.equals("")) {
			model.addAttribute("error", "Please fill your email!");
			return getForgotPassword(model);
		} 
		AccountModel user = loginService.getUser(email);
		if(user == null) {
			model.addAttribute("error", "Your email is never exists. Try other email!");
			model.addAttribute("email", email);
			return getForgotPassword(model);
		}
		
		//send email
		// end send email
		
		forgotPasswordService.generateSessionForgotPassword(user, req);
		
		return "redirect: re-password";
		
	}
	
	@GetMapping("/re-password")
	public String getRePassword(Model model) {
		title = "Re password";
		pageName = "re-password";
		
		model.addAttribute("title", title);
		model.addAttribute("pageName", pageName);
		
		return "main-frame";
	}
	
	@PostMapping("/re-password")
	public String postRePassword(Model model, HttpServletRequest req) {
		String newPassword = req.getParameter("newPassword");
		String rePassword = req.getParameter("rePassword");
		
		if(!newPassword.equals(rePassword)) {
			model.addAttribute("error", "New password and Repeat password must be same!");
			model.addAttribute("newPassword", newPassword);
			model.addAttribute("rePassword", rePassword);
			return getRePassword(model);
		}
		
		if(!forgotPasswordService.changePasswordForUser(req, newPassword)) {
			model.addAttribute("message", "Your infomation produce is incorrect. Please try again!");
			return "redirect: error";
		}
		title = "Change password success";
		pageName = "change-password-success";
		
		model.addAttribute("title", title);
		model.addAttribute("pageName", pageName);
		
		return "main-frame";
		
	}
}
