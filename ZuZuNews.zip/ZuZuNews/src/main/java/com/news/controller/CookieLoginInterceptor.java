package com.news.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.news.model.AccountModel;
import com.news.service.LoginService;

@Component
@RequestMapping(method = RequestMethod.GET)

public class CookieLoginInterceptor extends HandlerInterceptorAdapter{

	@Autowired
	LoginService loginService;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		
		String email = loginService.getCookieLogin(request);
		if(loginService.getSessionLogin(request) == null && email != null) {
			AccountModel user = loginService.getUser(email);
			if(user != null) {
				loginService.generateSessionLogin(user, request);
			}
		}
		return true;
	}
	
	
}
