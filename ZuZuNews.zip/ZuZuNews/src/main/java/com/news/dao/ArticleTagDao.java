package com.news.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.news.entity.Article;
import com.news.entity.ArticleTag;

@Repository
public interface ArticleTagDao extends JpaRepository<ArticleTag, Long>{

	//get by article
	@Query(value = "select a from ArticleTag a where a.article.id = :articleId")
	public List<ArticleTag> getByArticle(@Param("articleId") Long articleId);
	
	//get by tag
	@Query(value = "select * from article_tag where tag_id = :tagId", nativeQuery = true)
	public List<ArticleTag> getByTag(@Param("tagId") Long tagId);
	
	
}
