package com.news.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.news.entity.Slide;

@Repository
public interface SlideDao extends JpaRepository<Slide, Long>{

}
