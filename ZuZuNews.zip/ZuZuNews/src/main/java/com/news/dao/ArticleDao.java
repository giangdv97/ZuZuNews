package com.news.dao;


import java.util.List;

import org.hibernate.annotations.Parent;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.news.entity.Article;

@Repository
public interface ArticleDao extends JpaRepository<Article, Long> {

	// Trending article, 10 of 30 newest and most view count
	@Query(nativeQuery = true, value = "select * from article where active = 1 and id in"
			+ " (select * from (select id from article where active = 1 and category_article_id = :catId order by created_at desc limit 30) abc)"
			+ "order by view desc limit 10")
	public List<Article> get10ArticlesNewestAndMostViewByCategoryId(@Param("catId") Long catId);
	
	//Newest article with limit
	@Query(nativeQuery = true, value = "select * from article where active = 1 and category_article_id = :catId order by created_at desc limit :limitNumber")
	public  List<Article> getArticlesNewestByCategoryIdwithLimit(@Param("catId") Long catId, @Param("limitNumber") int limit);
	
	//Newest article with pageable
	@Query(nativeQuery = true, value = "select * from article where active = 1 and category_article_id = :catId order by created_at desc")
	public List<Article> getArticlesNewestByCategoryIdwithPageable(@Param("catId") Long catId, Pageable pageable);
	
	//Most view article
	@Query(value = "select * from article where active = 1 order by view desc limit :limit", nativeQuery = true)
	public List<Article> getMostViewArticles(@Param("limit") int limit);
	
	//Most comment articles
	@Query(nativeQuery = true, value = "select * from article where active = 1 order by number_of_comment desc limit :limit")
	public List<Article> getMostCommentArticles(@Param("limit") int limit);
	
	//popular articles
	@Query(value = "select a from Article a where a.active = 1 order by a.view desc, a.numberOfComment desc")
	public List<Article> getPopularArticle(Pageable page);
	
	@Query("select a from Article a join fetch a.comments where a.active = 1 and a.id = :id")
	public Article getArticleWithComments(@Param("id") long id);
}
