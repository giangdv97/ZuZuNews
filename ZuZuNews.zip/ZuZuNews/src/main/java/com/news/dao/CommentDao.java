package com.news.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.news.entity.Comment;

@Repository
public interface CommentDao extends JpaRepository<Comment, Long>{

	@Query(nativeQuery = true, value = "INSERT INTO comment ('content', 'user_id', 'article_id', 'created_at', 'active', 'comment_parent') VALUES ('Haiz chan qua 2', '584', '281', '2019-01-11 23:05:48', '1', '0').executeUpdate()")
	public void insert();
}
