package com.news.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.news.entity.Article;
import com.news.entity.ArticleTag;
import com.news.model.ArticleModel;
import com.news.model.TagModel;

@Service

public class ArticleService {

	private ArticleModel articleModel;

	@Autowired
	CommentService commentService;
	@Autowired
	ArticleTagService articleTagService;
	@Autowired
	TagService tagService;

	public ArticleModel convertArticleToArticleModel(Article article) {
		articleModel = new ArticleModel();
		articleModel.setId(article.getId());
		articleModel.setActive(article.getActive());
		articleModel.setViews(article.getView());
		articleModel.setCategory(article.getCategoryArticle());
		articleModel.setCommentCount(article.getNumberOfComment());
		articleModel.setContent(article.getContent());
		articleModel.setCreatedAt(article.getCreatedAt());
		articleModel.setDescription(article.getDescription());
		articleModel.setSlug(article.getSlug());
		articleModel.setTag(article.getTag());
		articleModel.setThumb(article.getThumb());
		articleModel.setTitle(article.getTitle());
		articleModel.setUpdatedAt(article.getUpdatedAt());
		articleModel.setComments(commentService.getCommentParent(article.getComments()));
		articleModel.setTags(getTagModelByArticleTag(article));

		return articleModel;
	}

	public Article convertArticleModelToArticle(ArticleModel articleModel) {
		Article article = new Article();
		article.setId(articleModel.getId());
		article.setActive(articleModel.getActive());
		article.setCategoryArticle(articleModel.getCategory());
		article.setNumberOfComment(articleModel.getCommentCount());
		article.setContent(articleModel.getContent());
		article.setCreatedAt(articleModel.getCreatedAt());
		article.setDescription(articleModel.getDescription());
		article.setSlug(articleModel.getSlug());
		article.setTag(articleModel.getTag());
		article.setThumb(articleModel.getThumb());
		article.setTitle(articleModel.getTitle());
		article.setUpdatedAt(articleModel.getUpdatedAt());

		return article;
	}

	public List<TagModel> getTagModelByArticleTag(Article article) {
		List<TagModel> tagModels = new ArrayList<TagModel>();
		List<ArticleTag> articleTags = articleTagService.getArticleTagsByArticle(article);
		for (ArticleTag articleTag : articleTags) {
			TagModel tagModel = new TagModel();
			tagModel = tagService.convertTagToTagModel(articleTag.getTag());
			tagModels.add(tagModel);
		}
		return tagModels;
	}

	public List<Article> getRelatedArticles(List<TagModel> tagModels, Long id) {
		List<Article> relatedArticles = new ArrayList<Article>();
		for (TagModel t : tagModels) {
			for (Article a : articleTagService.getArticlesByTagModel(t.getId())) {
				if (!a.getId().toString().equals(id.toString())) {
					relatedArticles.add(a);
				}
			}
		}
		return relatedArticles;
	}
	
	public List<Article> getArticlesByTag(Long tagId){
		List<Article> articles = articleTagService.getArticlesByTagModel(tagId);
		return articles;
	}
	
	

}
