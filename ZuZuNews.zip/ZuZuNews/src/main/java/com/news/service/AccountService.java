package com.news.service;

import org.springframework.stereotype.Service;

import com.news.entity.Account;
import com.news.model.AccountModel;

@Service

public class AccountService {

	public Account convertAccountModelToAccount(AccountModel accountModel) {
		Account account = new Account();
		account.setId(accountModel.getId());
		account.setActive(accountModel.getActive());
		account.setAvatar(accountModel.getAvatar());
		account.setCreatedAt(accountModel.getCreatedAt());
		account.setEmail(accountModel.getEmail());
		account.setFullname(accountModel.getFullname());
		account.setPassword(accountModel.getPassword());
		account.setRole(accountModel.getRole());
		account.setUpdatedAt(accountModel.getUpdatedAt());
		account.setSlug(accountModel.getSlug());
		return account;
	}
	public AccountModel convertAccountToAccountModel(Account account) {
		AccountModel accountModel = new AccountModel();
		accountModel.setId(account.getId());
		accountModel.setActive(account.getActive());
		accountModel.setAvatar(account.getAvatar());
		accountModel.setCreatedAt(account.getCreatedAt());
		accountModel.setEmail(account.getEmail());
		accountModel.setFullname(account.getFullname());
		accountModel.setPassword(account.getPassword());
		accountModel.setRole(account.getRole());
		accountModel.setUpdatedAt(account.getUpdatedAt());
		accountModel.setSlug(account.getSlug());
		return accountModel;
	}
}
