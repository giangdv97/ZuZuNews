package com.news.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.news.dao.ArticleDao;
import com.news.entity.Article;
import com.news.entity.CategoryArticle;
import com.news.model.CategoryArticleModel;

@Service
public class CategoryService {

	@Autowired
	ArticleDao articleDao;

	List<CategoryArticleModel> categoryArticleModelList;

	public List<CategoryArticleModel> getTrendingArticlesByCategoryId(List<CategoryArticle> cats) {

		categoryArticleModelList = new ArrayList<CategoryArticleModel>();
		CategoryArticleModel categoryArticleModel;

		for (CategoryArticle cat : cats) {
			categoryArticleModel = new CategoryArticleModel();
			categoryArticleModel.setId(cat.getId());
			categoryArticleModel.setTitle(cat.getTitle());
			categoryArticleModel.setArticles(articleDao.get10ArticlesNewestAndMostViewByCategoryId(cat.getId()));

			categoryArticleModelList.add(categoryArticleModel);

		}

		return categoryArticleModelList;
	}

	public List<CategoryArticleModel> getNewestArticlesByCategoryIdWithLimit(List<CategoryArticle> cats, int limit) {

		categoryArticleModelList = new ArrayList<CategoryArticleModel>();
		CategoryArticleModel categoryArticleModel;

		for (CategoryArticle cat : cats) {

			categoryArticleModel = new CategoryArticleModel();
			categoryArticleModel.setId(cat.getId());
			categoryArticleModel.setTitle(cat.getTitle());
			categoryArticleModel.setArticles(articleDao.getArticlesNewestByCategoryIdwithLimit(cat.getId(), limit));

			categoryArticleModelList.add(categoryArticleModel);

		}

		return categoryArticleModelList;
	}

	public List<CategoryArticleModel> getNewestArticlesByCategoryIdWithPageable(List<CategoryArticle> cats, int page,
			int maxResult) {

		categoryArticleModelList = new ArrayList<CategoryArticleModel>();
		CategoryArticleModel categoryArticleModel;

		for (CategoryArticle cat : cats) {

			categoryArticleModel = new CategoryArticleModel();
			categoryArticleModel.setId(cat.getId());
			categoryArticleModel.setTitle(cat.getTitle());
			categoryArticleModel.setArticles(
					articleDao.getArticlesNewestByCategoryIdwithPageable(cat.getId(), PageRequest.of(page, maxResult)));

			categoryArticleModelList.add(categoryArticleModel);
		}

		return categoryArticleModelList;
	}

	public String checkCategoryIdValid(List<CategoryArticle> cats, long catId) {
		for (CategoryArticle cat : cats) {
			if (catId == cat.getId()) {
				return cat.getTitle();
			}
		}

		return "";
	}
	
	public CategoryArticleModel getAllArticleByCatId(String catTitle, long catId, int page, int maxResult) {
		CategoryArticleModel cat = new CategoryArticleModel();
		List<Article> aList = articleDao.getArticlesNewestByCategoryIdwithPageable(catId, PageRequest.of(page, maxResult));
		cat.setId(catId);
		cat.setTitle(catTitle);
		cat.setArticles(aList);
		return cat;
	}
	

	public String getCategoryTitleById(long categoryId, List<CategoryArticle> cats) {
		for (CategoryArticle c : cats) {
			if(categoryId == c.getId())
				return c.getTitle();
		}
		return "";
	}
}
