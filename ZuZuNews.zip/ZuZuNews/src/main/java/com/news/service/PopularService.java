package com.news.service;

import java.text.SimpleDateFormat;

import org.springframework.stereotype.Service;

import com.news.entity.Article;
import com.news.model.ArticleModel;

@Service

public class PopularService {

	SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm");
	
	public ArticleModel convert(Article a) {
		
		ArticleModel ar = new ArticleModel();
		ar.setActive(a.getActive());
		ar.setThumb(a.getThumb());
		ar.setId(a.getId());
		ar.setDescription(a.getDescription());
		ar.setCreatedAt(a.getCreatedAt());
		ar.setUpdatedAt(a.getUpdatedAt());
		ar.setCommentCount(a.getNumberOfComment());
		ar.setViews(a.getView());
		ar.setTitle(a.getTitle());
		ar.setSlug(a.getSlug());
		ar.setContent(a.getContent());
		return ar;
	}
}
