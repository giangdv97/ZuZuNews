package com.news.service;

import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.news.dao.AccountDao;
import com.news.entity.Account;
import com.news.model.AccountModel;

@Service

public class LoginService {

	private final String SESSION_NAME = "SESSION_LOGIN";
	private final String COOKIE_NAME = "COOKIE_LOGIN";
	
	@Autowired
	AccountDao accountDao;

	public AccountModel getUser(String email) {
		Account account = accountDao.getUserByEmail(email);
		if (account != null) {
			AccountModel accountModel = new AccountModel();
			accountModel.setId(account.getId());
			accountModel.setActive(account.getActive());
			accountModel.setAvatar(account.getAvatar());
			accountModel.setCoockie(account.getCookieLogin());
			accountModel.setCreatedAt(account.getCreatedAt());
			accountModel.setEmail(account.getEmail());
			accountModel.setFullname(account.getFullname());
			accountModel.setPassword(account.getPassword());
			accountModel.setRole(account.getRole());
			accountModel.setSlug(account.getSlug());
			accountModel.setUpdatedAt(account.getUpdatedAt());
			return accountModel;
		}
		return null;
	}
	
	public void addInfoLoginIntoModel(Model model, Map infoLogin) {
		model.addAttribute("email", infoLogin.get("email"));
		model.addAttribute("password", infoLogin.get("password"));
		model.addAttribute("remember", infoLogin.get("remember"));
	}
	
	public boolean checkPassword(Map infoLogin, AccountModel user) {
		if(infoLogin.get("password").equals(user.getPassword()))
			return true;
		else
			return false;
	}
	
	public boolean checkActive(AccountModel user) {
		if(user.getActive() == 1)
			return true;
		else
			return false;
	}
	
	public boolean isAdmin(AccountModel user) {
		if(user.getRole() >= 1000)
			return true;
		return false;
	}
	
	public void generateCookieLogin(AccountModel user, HttpServletResponse res) {
		Cookie cookieLogin = new Cookie(COOKIE_NAME, user.getEmail());
		cookieLogin.setMaxAge(10 * 24 * 60 * 60);
		res.addCookie(cookieLogin);
	}
	
	public void generateSessionLogin(AccountModel user, HttpServletRequest req) {
		HttpSession ss = req.getSession();
		ss.setAttribute(SESSION_NAME, user);
	}
	
	public AccountModel getSessionLogin(HttpServletRequest req) {
		HttpSession ss = req.getSession();
		if(ss.getAttribute(SESSION_NAME) != null)
			return (AccountModel) ss.getAttribute(SESSION_NAME);
		return null;
	}
	
	public String getCookieLogin(HttpServletRequest req) {
		Cookie[] cookies = req.getCookies();
		if(cookies != null)
			for (Cookie cookie : cookies) {
				if(cookie.getName().equals(COOKIE_NAME))
					return cookie.getValue();
			}
		return null;
	}
	
	public void deleteSessionLogin(HttpServletRequest req) {
		HttpSession ss = req.getSession();
		ss.removeAttribute(SESSION_NAME);
	}
	
	public void deleteCookieLogin(HttpServletResponse res) {
		Cookie cookie =  new Cookie(COOKIE_NAME, null);
		cookie.setMaxAge(0);
		res.addCookie(cookie);
	}
}
