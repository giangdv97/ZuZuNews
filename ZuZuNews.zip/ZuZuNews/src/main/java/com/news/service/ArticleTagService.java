package com.news.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.news.dao.ArticleTagDao;
import com.news.entity.Article;
import com.news.entity.ArticleTag;
import com.news.entity.Tag;

@Service

public class ArticleTagService {

	private List<ArticleTag> articleTags;

	@Autowired
	ArticleTagDao articleTagDao;

	public List<ArticleTag> getArticleTagsByArticle(Article article) {
		articleTags = new ArrayList<ArticleTag>();
		articleTags = articleTagDao.getByArticle(article.getId());
		return articleTags;
	}

	public List<ArticleTag> getArticleTagsByTag(Tag tag) {
		articleTags = new ArrayList<ArticleTag>();
		articleTags = articleTagDao.getByTag(tag.getId());
		return articleTags;
	}

	public List<Article> getArticlesByTagModel(Long tagId) {
		List<Article> articles = new ArrayList<Article>();
		articleTags = articleTagDao.getByTag(tagId);
		for (ArticleTag articleTag : articleTags) {
			if (articleTag.getArticle().getActive() == 1)
				articles.add(articleTag.getArticle());
		}
		return articles;
	}
}
