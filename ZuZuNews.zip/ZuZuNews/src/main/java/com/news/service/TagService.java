package com.news.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.news.dao.TagDao;
import com.news.entity.Tag;
import com.news.model.TagModel;

@Service

public class TagService {

	private TagModel tagModel;
	
	@Autowired
	TagDao tagDao;
	
	public TagModel convertTagToTagModel(Tag tag) {
		tagModel = new TagModel();
		tagModel.setId(tag.getId());
		tagModel.setTitle(tag.getTitle());
		return tagModel;
	}
	
}
