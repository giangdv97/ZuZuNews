package com.news.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.news.dao.ArticleDao;
import com.news.dao.CommentDao;
import com.news.entity.Comment;
import com.news.model.CommentModel;

@Service

public class CommentService {

	private List<CommentModel> commentModels;
	
	@Autowired
	CommentDao commentDao;
	@Autowired
	ArticleDao articleDao;
	@Autowired
	LoginService loginService;
	@Autowired
	AccountService accountService;
	
	public CommentModel convertCommentToCommentModel(CommentModel commentModel, Comment comment) {
		
		commentModel.setId(comment.getId());
		commentModel.setActive(comment.getActive());
		commentModel.setContent(comment.getContent());
		commentModel.setCreatedAt(comment.getCreatedAt());
		commentModel.setUser(comment.getAccount());
		return commentModel;
	}
	
	public List<CommentModel> getCommentParent(List<Comment> comments){
		commentModels = new ArrayList<CommentModel>();
		for (Comment comment : comments) {
			if(comment.getCommentParent() == 0) {
				CommentModel commentModel = new CommentModel();
				commentModels.add(convertCommentToCommentModel(commentModel, comment));
				getCommentChild(commentModel, comments);
				
				
			}
		}
		
		return commentModels;
	}
	
	public void getCommentChild(CommentModel commentModel, List<Comment> comments){
		for (Comment comment : comments) {
			if(comment.getCommentParent() == commentModel.getId()) {
				System.out.println(comment.getContent() + "; cha " + commentModel.getContent());
				CommentModel commentModelChild = new CommentModel();
				commentModel.getCommentChild().add(convertCommentToCommentModel(commentModelChild, comment));
				getCommentChild(commentModelChild, comments);
			}
		}
	}
	
	public void saveComment(long articleId, long commentParentId, String content, HttpServletRequest req) {
		Comment comment = new Comment();
		comment.setActive(1);
		comment.setCommentParent(commentParentId);
		comment.setContent(content);
		comment.setCreatedAt(new Date());
		comment.setArticle(articleDao.findById(articleId).get());
		comment.setAccount(accountService.convertAccountModelToAccount(loginService.getSessionLogin(req)));
		commentDao.save(comment);
		
	}
}
