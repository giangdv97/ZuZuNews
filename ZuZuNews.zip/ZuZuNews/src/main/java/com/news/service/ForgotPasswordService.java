package com.news.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.news.dao.AccountDao;
import com.news.entity.Account;
import com.news.model.AccountModel;

@Service

public class ForgotPasswordService {

	private final String SESSION_NAME = "FORGOT_PASSWORD";
	@Autowired
	AccountDao accountDao;

	public void generateSessionForgotPassword(AccountModel account, HttpServletRequest req) {
		HttpSession ss = req.getSession();
		ss.setAttribute(SESSION_NAME, account);
	}

	public boolean changePasswordForUser(HttpServletRequest req, String newPassword) {
		HttpSession ss = req.getSession();
		AccountModel account = (AccountModel) ss.getAttribute(SESSION_NAME);
		long id = account.getId();

		Account acc = accountDao.findById(id).get();
		if (acc != null) {
			acc.setPassword(newPassword);
			accountDao.save(acc);
			return true;
		} else
			return false;
		
	}

	// send email

}
