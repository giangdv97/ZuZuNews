package com.news.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the tag database table.
 * 
 */
@Entity
@Table(name="tag")
@NamedQuery(name="Tag.findAll", query="SELECT t FROM Tag t")
public class Tag implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long id;

	private String title;

	//bi-directional many-to-one association to ArticleTag
	@OneToMany(mappedBy="tag", fetch = FetchType.EAGER)
	private List<ArticleTag> articleTags;

	public Tag() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<ArticleTag> getArticleTags() {
		return this.articleTags;
	}

	public void setArticleTags(List<ArticleTag> articleTags) {
		this.articleTags = articleTags;
	}

	public ArticleTag addArticleTag(ArticleTag articleTag) {
		getArticleTags().add(articleTag);
		articleTag.setTag(this);

		return articleTag;
	}

	public ArticleTag removeArticleTag(ArticleTag articleTag) {
		getArticleTags().remove(articleTag);
		articleTag.setTag(null);

		return articleTag;
	}

}