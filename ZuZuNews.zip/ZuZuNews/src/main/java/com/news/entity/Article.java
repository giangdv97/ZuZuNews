package com.news.entity;

import java.io.Serializable;
import java.text.SimpleDateFormat;

import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the article database table.
 * 
 */
@Entity
@Table(name="article")
@NamedQuery(name="Article.findAll", query="SELECT a FROM Article a")
public class Article implements Serializable {
	private static final long serialVersionUID = 1L;

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	private Long id;

	private int active;

	@Lob
	private String content;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_at")
	private Date createdAt;

	@Lob
	private String description;

	@Column(name="number_of_comment")
	private int numberOfComment;

	private String slug;

	@Lob
	private String tag;

	private String thumb;

	private String title;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_at")
	private Date updatedAt;

	private int view;

	//bi-directional many-to-one association to CategoryArticle
	@ManyToOne
	@JoinColumn(name="category_article_id")
	private CategoryArticle categoryArticle;

	//bi-directional many-to-one association to ArticleTag
	@OneToMany(mappedBy="article", fetch = FetchType.LAZY)
	private List<ArticleTag> articleTags;

	//bi-directional many-to-one association to Comment
	@OneToMany(mappedBy="article", fetch = FetchType.LAZY)
	private List<Comment> comments;

	//bi-directional many-to-one association to Slide
	@OneToMany(mappedBy="article", fetch = FetchType.LAZY)
	private List<Slide> slides;

	//bi-directional many-to-one association to View
	@OneToMany(mappedBy="article", fetch = FetchType.LAZY)
	private List<View> views;

	public Article() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getActive() {
		return this.active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getNumberOfComment() {
		return this.numberOfComment;
	}

	public void setNumberOfComment(int numberOfComment) {
		this.numberOfComment = numberOfComment;
	}

	public String getSlug() {
		return this.slug;
	}

	public void setSlug(String slug) {
		this.slug = slug;
	}

	public String getTag() {
		return this.tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getThumb() {
		return this.thumb;
	}

	public void setThumb(String thumb) {
		this.thumb = thumb;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public int getView() {
		return this.view;
	}

	public void setView(int view) {
		this.view = view;
	}

	public CategoryArticle getCategoryArticle() {
		return this.categoryArticle;
	}

	public void setCategoryArticle(CategoryArticle categoryArticle) {
		this.categoryArticle = categoryArticle;
	}

	public List<ArticleTag> getArticleTags() {
		return this.articleTags;
	}

	public void setArticleTags(List<ArticleTag> articleTags) {
		this.articleTags = articleTags;
	}

	public ArticleTag addArticleTag(ArticleTag articleTag) {
		getArticleTags().add(articleTag);
		articleTag.setArticle(this);

		return articleTag;
	}

	public ArticleTag removeArticleTag(ArticleTag articleTag) {
		getArticleTags().remove(articleTag);
		articleTag.setArticle(null);

		return articleTag;
	}

	public List<Comment> getComments() {
		return this.comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}

	public Comment addComment(Comment comment) {
		getComments().add(comment);
		comment.setArticle(this);

		return comment;
	}

	public Comment removeComment(Comment comment) {
		getComments().remove(comment);
		comment.setArticle(null);

		return comment;
	}

	public List<Slide> getSlides() {
		return this.slides;
	}

	public void setSlides(List<Slide> slides) {
		this.slides = slides;
	}

	public Slide addSlide(Slide slide) {
		getSlides().add(slide);
		slide.setArticle(this);

		return slide;
	}

	public Slide removeSlide(Slide slide) {
		getSlides().remove(slide);
		slide.setArticle(null);

		return slide;
	}

	public List<View> getViews() {
		return this.views;
	}

	public void setViews(List<View> views) {
		this.views = views;
	}

	public View addView(View view) {
		getViews().add(view);
		view.setArticle(this);

		return view;
	}

	public View removeView(View view) {
		getViews().remove(view);
		view.setArticle(null);

		return view;
	}
	
	public String getDateTime() {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		return df.format(getCreatedAt());
	}

}