package com.news.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the category_article database table.
 * 
 */
@Entity
@Table(name="category_article")
@NamedQuery(name="CategoryArticle.findAll", query="SELECT c FROM CategoryArticle c")
public class CategoryArticle implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long id;

	@Column(name="category_parent")
	private Long categoryParent;

	private String title;

	//bi-directional many-to-one association to Article
	@OneToMany(mappedBy="categoryArticle")
	private List<Article> articles;

	public CategoryArticle() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getCategoryParent() {
		return this.categoryParent;
	}

	public void setCategoryParent(Long categoryParent) {
		this.categoryParent = categoryParent;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<Article> getArticles() {
		return this.articles;
	}

	public void setArticles(List<Article> articles) {
		this.articles = articles;
	}

	public Article addArticle(Article article) {
		getArticles().add(article);
		article.setCategoryArticle(this);

		return article;
	}

	public Article removeArticle(Article article) {
		getArticles().remove(article);
		article.setCategoryArticle(null);

		return article;
	}

}