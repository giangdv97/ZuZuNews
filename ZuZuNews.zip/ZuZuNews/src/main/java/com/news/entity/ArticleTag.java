package com.news.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the article_tag database table.
 * 
 */
@Entity
@Table(name="article_tag")
@NamedQuery(name="ArticleTag.findAll", query="SELECT a FROM ArticleTag a")
public class ArticleTag implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long id;

	//bi-directional many-to-one association to Article
	@ManyToOne
	private Article article;

	//bi-directional many-to-one association to Tag
	@ManyToOne
	private Tag tag;

	public ArticleTag() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Article getArticle() {
		return this.article;
	}

	public void setArticle(Article article) {
		this.article = article;
	}

	public Tag getTag() {
		return this.tag;
	}

	public void setTag(Tag tag) {
		this.tag = tag;
	}

}